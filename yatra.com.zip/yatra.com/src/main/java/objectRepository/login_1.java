package objectRepository;

import org.openqa.selenium.By;

public class login_1 {
	public static By myAccount_Hover = By.xpath("//a[@class='dropdown-toggle']");
	
	public static By ClickLogin = By.id("signInBtn");
	
	public static By inputEmail = By.id("login-input");
	
	public static By clickContinue = By.id("login-continue-btn");
	
	public static By inputPassword = By.id("login-password");
	
	public static By ClickLogin_2 = By.id("login-submit-btn");
	
}
